package com.example.Cache.demo.model;

import org.springframework.data.repository.CrudRepository;

public interface StoryRepositary extends CrudRepository<Stories,Long> {


}
