package com.example.Cache.demo.model;


import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.Arrays;

public class Comment  {
    private String by;
    @JsonIgnore
    private String id;
    @JsonIgnore
    private Integer[] kids;
    @JsonIgnore
    private String parent;
    private String text;
    @JsonIgnore
    private String time;
    @JsonIgnore
    private String type;

    @Override
    public String toString() {
        return "Comment{" +
                "by='" + by + '\'' +
                ", id='" + id + '\'' +
                ", kids=" + Arrays.toString(kids) +
                ", parent='" + parent + '\'' +
                ", text='" + text + '\'' +
                ", time='" + time + '\'' +
                ", type='" + type + '\'' +
                '}';
    }


    public String getBy() {
        return by;
    }

    public void setBy(String by) {
        this.by = by;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer[] getKids() {
        return kids;
    }

    public void setKids(Integer[] kids) {
        this.kids = kids;
    }

    public String getParent() {
        return parent;
    }

    public void setParent(String parent) {
        this.parent = parent;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }



}

