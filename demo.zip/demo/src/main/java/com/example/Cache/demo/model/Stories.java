package com.example.Cache.demo.model;


import javax.persistence.*;
import java.io.Serializable;
import java.util.List;


@Entity
public class Stories implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id_story;
    private String title;
    private String url;
    private Long score;
    private String timeOfSubmission;
    private String story_user;
    private Long id;
    @ElementCollection
    private List<Integer> kids;
    private String type;
    private Long descendants;

    public Long getDescendants() {
        return descendants;
    }

    public void setDescendants(Long descendants) {
        this.descendants = descendants;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public List<Integer> getKids() {
        return kids;
    }

    public void setKids(List<Integer> kids) {
        this.kids = kids;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Long getScore() {
        return score;
    }

    public void setScore(Long score) {
        this.score = score;
    }

    public String getTime() {
        return timeOfSubmission;
    }

    public void setTime(String timeOfSubmission) {

        this.timeOfSubmission = timeOfSubmission;
    }

    public String getBy() {
        return story_user;
    }

    public void setBy(String story_user) {
        this.story_user = story_user;
    }
}
