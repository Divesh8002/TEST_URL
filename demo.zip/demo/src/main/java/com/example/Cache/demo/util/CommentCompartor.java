package com.example.Cache.demo.util;

import com.example.Cache.demo.model.Comment;

import java.util.Comparator;

public class CommentCompartor implements Comparator<Comment> {

    @Override
    public int compare(Comment e1, Comment e2){
        if (e1.getKids()== null && e2.getKids() == null) {
            return 0;
        } else if(e1.getKids() == null) {
            return -1;
        } else if(e2.getKids() == null) {
            return 1;
        } else {
            return Integer.toString(e1.getKids().length).compareTo(Integer.toString(e2.getKids().length));
        }
    }
}
