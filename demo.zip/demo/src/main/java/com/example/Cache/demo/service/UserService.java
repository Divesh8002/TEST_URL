package com.example.Cache.demo.service;


import com.example.Cache.demo.Response.StoryRes;
import com.example.Cache.demo.model.Comment;
import com.example.Cache.demo.model.Stories;
import com.example.Cache.demo.model.StoryRepositary;
import com.example.Cache.demo.util.CommentCompartor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.*;
import java.util.stream.Collectors;


@Service
public class UserService {

    @Autowired
    StoryRes storyRes;

    @Autowired
    private StoryRepositary storyRepositary;
    private final RestTemplate restTemplate;
    public static List<Stories> past_story;
    public static final String URL = "https://hacker-news.firebaseio.com/v0/item/%d.json?print=pretty";
    //Using Best Story URL as its getting sorted Stories by Score
    public static final String BEST_STORY = "https://hacker-news.firebaseio.com/v0/beststories.json?print=pretty";

    public UserService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    // @Cacheable(cacheNames = "top_story", key = "#bankId", unless = "#result == null")
    @Cacheable(cacheNames = "top_story")
    public List<StoryRes> get_top_Stories() {

        List response = restTemplate.getForObject(BEST_STORY, List.class);
        List topStories = new ArrayList<StoryRes>();
        System.out.println("Fetching data from DB");

        //For First top Ten story Sorted by Score
        int count_story = 0;
        for (int i = 0; i < response.size() && count_story<10; i++) {
            Stories stories = restTemplate.getForObject(String.format(URL, response.get(i)), Stories.class);
            if (stories.getTitle() != null && stories.getUrl() != null && stories.getBy() != null && stories.getScore() != null && stories.getTime() != null
            ) {

                this.storyRepositary.save(stories);
                topStories.add(this.storyRes.convertStoryToStoryResponse(stories));
                count_story++;
            }
        }
        past_story = topStories;
        return topStories;
    }

    public List<Stories> get_past_Stories() {
        return past_story;
    }

    public List<Comment> comments(Long id) {
        Stories stories = restTemplate.getForObject(String.format(URL, id), Stories.class);
        List<Comment> comments = new ArrayList<Comment>();
        for (Integer i : stories.getKids()) {
            Comment comment = restTemplate.getForObject(String.format(URL, i), Comment.class);
            comments.add(comment);
        }
        List<Comment> sortedCommentList = comments
                .stream()
                .sorted(Comparator.nullsFirst(new CommentCompartor()))
                .collect(Collectors.toList());
        Collections.reverse(sortedCommentList);
        List top_comments = new ArrayList<Comment>();

        int count = 0;
        for (int i = 0;count < 10 && i < sortedCommentList.size(); i++) {

            if ( sortedCommentList.get(i).getBy() != null && sortedCommentList.get(i).getText() != null) {
                top_comments.add(sortedCommentList.get(i));
                count++;
            }
       }
        return top_comments;
    }

}
