package com.example.Cache.demo.controller;


import com.example.Cache.demo.Response.StoryRes;
import com.example.Cache.demo.model.Comment;
import com.example.Cache.demo.model.Stories;
import com.example.Cache.demo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class UserController {

    @Autowired
    private UserService userService;

    @GetMapping("/top_stories")
    public List<StoryRes> get_top_Stories(){
        return userService.get_top_Stories();
    }

    @GetMapping("/past_stories")
    public List<Stories> get_past_Stories(){
        return userService.get_past_Stories();}

    @GetMapping("/comments/{id}")
    public List<Comment> comments(@PathVariable Long id){
        return userService.comments(id);
    }

}
