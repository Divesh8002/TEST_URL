package com.example.Cache.demo.Response;

import com.example.Cache.demo.model.Stories;
import org.springframework.stereotype.Component;

import java.io.Serializable;

@Component
public class StoryRes  implements Serializable {
    private String title;
    private String url;
    private Long score;
    private String timeOfSubmission;
    private String story_user;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Long getScore() {
        return score;
    }

    public void setScore(Long score) {
        this.score = score;
    }

    public String getTime() {
        return timeOfSubmission;
    }

    public void setTime(String timeOfSubmission) {
        this.timeOfSubmission = timeOfSubmission;
    }

    public String getBy() {
        return story_user;
    }

    public void setBy(String story_user) {
        this.story_user = story_user;
    }



    public StoryRes convertStoryToStoryResponse(Stories stories) {
        StoryRes storyRes=  new StoryRes();
        storyRes.score = stories.getScore();
        storyRes.title = stories.getTitle();
        storyRes.url = stories.getUrl();
        storyRes.story_user = stories.getBy();
        storyRes.timeOfSubmission = stories.getTime();
        return storyRes;
    }
}
